package main;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;

public class MainDraw extends JComponent {

    public int x = 50;
    public int y = 50;

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawOval(x, y, 50, 50);
        g.fillOval(x, y, 50, 50);
        g.setColor(Color.BLACK);
    }

    public void moveRight() {
        x = x + 50;
        repaint();
    }

    public void moveLeft() {
        x = x - 50;
        repaint();
    }

    public void moveDown() {
        y = y + 50;
        repaint();
    }

    public void moveUp() {
        y = y - 50;
        repaint();
    }
}
