package main;

import java.util.Arrays;

public class Board {
	static String[] verticalBorder = {"F","F","F","F","F","F","F","F","F","F","F",};
	static String[] playSpace = {"-","-","-","-","-","-","-","-","-","-",};
	
	 static int row = 12; 
	 static int column = 12;
	static String[][] outline = new String[row][column];
	
	public static void buildBoard() {
		for(int i = 0; i <12; i++) {
			if (i == 0 || i == 11) outline[i] = verticalBorder;
			else outline[i] = playSpace;
		}
	}
	
	public static void printBoard(){
		String strRow;

		 for (int i = 0; i < 12; i++) {
			 strRow = Arrays.deepToString(outline[i]);
			 System.out.println(strRow);
		 }
	}	
	
	public static void init() {
		printBoard();
		buildBoard();
	}
}
