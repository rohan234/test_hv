package main;

import java.util.Arrays;

public class Board {
	//a-l is the mhos
	//# is the fence
	//
	static int min = 1;
	static int max = 11;
	static int range = max - min + 1;
	static int dim = 12; 
	
	
	static String[][] board = new String[dim][dim];

	public static void init() {
		//initializes the code
		buildBoard();
		printBoard();
	}
	
	
	
	//this is building the board
	public static void buildBoard() {
		//generates empty board
		for(int x = 0; x < dim; x++) {
			for (int y = 0; y < dim; y++) {
				
				if (x == 0 || x == dim - 1) {
					board[x][y] = "#";
				} else if (y == 0 || y == dim - 1) {
					board[x][y] = "#";
				} else {
					board[x][y] = "-";
				}
			}
		}
		
		genRandPlayer();
		//runs the function 20 times so we get 20 rand fences
		for(int i =0; i<20; i++) {
			genRandFence();
		}
		//making 12 mhos
		for(int j = 0; j<12; j++) {
			genRandMhos();
		}
		
	}
	
	
public static void genRandMhos() {
	int ranX = (int)(Math.random()*range)+min;
	int ranY = (int)(Math.random()*range)+min;
	
	if(board[ranY][ranX] == "-") {
		board[ranY][ranX] = "m";
	}
	else { 
		genRandMhos();
	}
	
	
	}
	public static void genRandPlayer() {
		int ranX = (int)(Math.random()*range)+min;
		int ranY = (int)(Math.random()*range)+min;
		
		if(board[ranY][ranX] == "-") {
			board[ranY][ranX] = "+";
		}
		else { 
			genRandPlayer();
		}
	}
	
	public static void genRandFence() {//generates a random location for the fence
		
		int ranX = (int)(Math.random()*range)+min;
		int ranY = (int)(Math.random()*range)+min;
		
		if(board[ranY][ranX] == "-") {
			board[ranY][ranX] = "#";
		}
		else { 
			genRandFence();
		}
	}
	
	//this is printing the board
	public static void printBoard(){
		
		

		for (int x = 0; x < dim; x++) {
			//make it into a string

			for (int y = 0; y < dim; y++) {
				System.out.print(board[x][y]);
			}
			System.out.println();
		}
		 
	}	
	
}
