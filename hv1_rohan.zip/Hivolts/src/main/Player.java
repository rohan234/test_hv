package main;

import java.awt.Color;
import java.awt.Graphics;
public class Player{
	//declaring fields
	static int x;
	static int y;
	int row, col;
	int radius = 50; 
	static int width = 50;
	static int height = 50;
	//makes the player
	public Player(int row, int column) {
		//look only at my fields 
		this.row = row;
		this.col = col;
		//col 1 is 50 col 2 is 100 etc
		this.x = (this.col * this.radius);
		this.y = (this.row * this.radius);
		
		//end of player constructor
	}
	
	public void move(int direction) {
		//east is 0
		//north is 1
		//west is 2
		//south is 3
		
		//filter the movement aka check before i move
		int colOffset = this.col;
		int rowOffset = this.row;
		//instace of draw
		MainFrame.draw.repaint();
		//filter the offsets based on which way i move
		switch ( direction ) {
		case 0:
			colOffset =+ 1;
			break;
		case 1:
			rowOffset -=1;
		}
		
	// ^ this is all pretty much useless	
		
	}
	
	public void draw(Graphics g) {
		  g.drawOval(this.x, this.y, this.radius, this.radius);
	        g.fillOval(this.x, this.y, this.radius, this.radius);
	        g.setColor(Color.BLACK);
		
		//end of draw method 
	}
	//^ also useless
	
	public static void playerDeath() {
		System.exit(1);
	}
	//gets the position of the player
	public static int[] getPosition() {
		for(int x = 0; x<12; x++) {
			for (int y = 0; y<12; y++) {
				if(Board.board[x][y] == "+") {
					int [] a = {x,y};
					return a;
				}
			}
		}
		System.out.println("BAD!!!");
		return null;
	}
	int[] xy = getPosition();
		
	//function to make it go right
	public static void right () {
		int[] xy = getPosition();
		Board.board[xy[0]][xy[1]] = "-";
		xy[1]++;
		if (Board.board[xy[0]][xy[1]] == "m") {
			playerDeath();
		}
		if (Board.board[xy[0]][xy[1]] == "#") {
			playerDeath();
		}
		else if (Board.board[xy[0]][xy[1]] == "-") {
			Board.board[xy[0]][xy[1]] = "+";
		}
		MainFrame.draw.repaint();
	}
	public static void left () {
		int[] xy = getPosition();
		Board.board[xy[0]][xy[1]] = "-";
		xy[1]--;
		if (Board.board[xy[0]][xy[1]] == "m") {
			playerDeath();
		}
		if (Board.board[xy[0]][xy[1]] == "#") {
			playerDeath();
		}
		else if (Board.board[xy[0]][xy[1]] == "-") {
			Board.board[xy[0]][xy[1]] = "+";
		}
		MainFrame.draw.repaint();
	}
	public static void down () {
		int[] xy = getPosition();
		Board.board[xy[0]][xy[1]] = "-";
		xy[0]++;
		if (Board.board[xy[0]][xy[1]] == "m") {
			playerDeath();
		}
		if (Board.board[xy[0]][xy[1]] == "#") {
			playerDeath();
		}
		else if (Board.board[xy[0]][xy[1]] == "-") {
			Board.board[xy[0]][xy[1]] = "+";
		}
		MainFrame.draw.repaint();
}
	public static void up () {
		int[] xy = getPosition();
		Board.board[xy[0]][xy[1]] = "-";
		xy[0]--;
		if (Board.board[xy[0]][xy[1]] == "m") {
			playerDeath();
		}
		if (Board.board[xy[0]][xy[1]] == "#") {
			playerDeath();
		}
		else if (Board.board[xy[0]][xy[1]] == "-") {
			Board.board[xy[0]][xy[1]] = "+";
		}
		MainFrame.draw.repaint();
}
	//end of player class
}
