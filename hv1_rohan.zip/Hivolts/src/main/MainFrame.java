package main;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;


public class MainFrame extends JFrame implements KeyListener{
    public static MainDraw draw;
    public void keyPressed(KeyEvent e) {
       // System.out.println("keyPressed");
    }

    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode()== KeyEvent.VK_D)
            Player.right();
        else if(e.getKeyCode()== KeyEvent.VK_A)
            Player.left();
        else if(e.getKeyCode()== KeyEvent.VK_S)
            Player.down();
        else if(e.getKeyCode()== KeyEvent.VK_W)
            Player.up();

    }
    public void keyTyped(KeyEvent e) {
       // System.out.println("keyTyped");
    }

    public MainFrame(){
        this.draw=new MainDraw();
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
    }

    public static void main(String[] args) {
    	
    	Board.init();
    	
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	
                MainFrame frame = new MainFrame();
                frame.setTitle("Hivolts Game");
                frame.setResizable(false);
                frame.setSize(615, 640);
                frame.setMinimumSize(new Dimension(615,640));
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.getContentPane().add(frame.draw);
                frame.pack();
                frame.setVisible(true);
            }
        });
    }
    
}