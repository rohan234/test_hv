package main;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;

public class MainDraw extends JComponent {

    public int x = 50;
    public int y = 50;
    public int width = 50;
    public int height = 50;
    
    
    
    public Player player = new Player(1,1);
    
//    public void paintFence(Graphics g, int x, int y) {
//    	g.setColor(Color.blue);
//    	g.fillRect(x, y, width, height);
//    }
//    
//    void createBorder(Graphics g) {
//    	for (int i = 0; i < 12; i++) {
//    		for (int x = 0; x < 12; x++) {
//    			if (i == 0 || i == 11) {
//    				paintFence(g, x * 50, i);
//    			}
//    		}
//    	}
//    }
    
    public void paintComponent(Graphics g) {
    	for (int i = 0; i < 12; i++) {
    		for (int x = 0; x < 12; x++) {
    			if (Board.board[x][i] == "#") {
    				g.setColor(Color.orange);
    				g.fillRect(50*i, 50*x, 50, 50);
    			}
    			if (Board.board[x][i] == "+") {
    				g.setColor(Color.black);
    				g.fillRect(50*i, x*50, 50, 50);
    			}
    			if (Board.board[x][i] == "-") {
    				g.setColor(Color.white);
    				g.fillRect(50*i, 50*x, 50,50);
    			}
    			if (Board.board[x][i] == "m") {
    				g.setColor(Color.blue);
    				g.drawRect(50*i, 50*x, 50,50);
    			}
    		}
    	}
    	Board.printBoard();
        
    }

}
